
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'STM32H503CBT6_VL53L8CX_Project1' 
 * Target:  'STM32H503CBT6_VL53L8CX_Project1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32h5xx.h"



#endif /* RTE_COMPONENTS_H */
